# snake-game
I built a simple snake game using JavaScript, HTML and CSS.
